<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>資料管理系統</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<h1>資料管理系統─PDO版本</h1>
<p><a href="item_list_page.php">分頁列表 (item_list_page)</a></p>
<p><a href="item_list_page.php">分頁列表 (item_list_page)</a></p>
<hr />
<p><a href="memb_list_page.php">分頁列表 (memb_list_page)</a></p>
<p><a href="memb_list_page.php">分頁列表 (memb_list_page)</a></p>
<hr />
<p><a href="_item_install_table.php">item_安裝資料表</a></p>
<p><a href="_memb_install_table.php">memb_安裝資料表</a></p>

</body>
</html>