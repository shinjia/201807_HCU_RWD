﻿<?php

$html = <<< HEREDOC
<h2>Welcome!</h2>
<br><br><br>
HEREDOC;

include 'pagemake.php';
pagemake($html);
?>